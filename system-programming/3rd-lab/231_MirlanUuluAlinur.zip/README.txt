runinfo.xml в папке processes определяет ограничения значений характеристик процесса.
config.json в папке processes/Processes хранит путь для файла runinfo.xml и число процессов, которые может запустить программа.
config.json в папаке processes/ProcessTracker.Library хранит путь где будут сохраняться логи