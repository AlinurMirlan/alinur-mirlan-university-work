﻿using Microsoft.Extensions.Configuration;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace ProcessDiagnostics.Library
{
    public class ProcessEventListener
    {
        private static readonly IConfiguration _config = new ConfigurationBuilder().AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\..\ProcessDiagnostics.Library\config.json")).Build();
        private static readonly string? _logFilePath = _config["processLogPath"];
        private readonly XmlWriterSettings _settings;
        private readonly XmlSerializerNamespaces _xmlns;
        private readonly LinkedList<ProcessEventInfo> _logs = new();
        private static string LogFilePath
        {
            get
            {
                if (_logFilePath is null)
                    throw new InvalidOperationException($"Config file hasn't been initialized.");

                return _logFilePath;
            }
        }

        public ProcessEventListener()
        {
            File.Create(LogFilePath).Dispose();
            _settings = new() { Indent = true, OmitXmlDeclaration = true };
            _xmlns = new(new[] { XmlQualifiedName.Empty });
        }

        public void Log(object? _, ProcessEventInfo processInfo) => _logs.AddLast(processInfo);

        public void Save()
        {
            using StreamWriter streamWriter = new(LogFilePath, true);
            StringBuilder xmlString = new();
            using StringWriter stringWriter = new(xmlString);
            XmlSerializer xmlSerializer = new(typeof(ProcessEventInfo));
            foreach (ProcessEventInfo log in _logs)
            {
                using XmlWriter xmlWriter = XmlWriter.Create(stringWriter, _settings);
                xmlSerializer.Serialize(xmlWriter, log, _xmlns);
                streamWriter.WriteLine(xmlString.ToString());
                xmlString.Clear();
            }
        }
    }
}
