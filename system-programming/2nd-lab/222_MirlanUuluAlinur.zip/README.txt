First version of the program writes logs on the fly, whilst the
second one stores them locally and serializes them at the end
of the program.