Introduction
Greetings, User. This application is used to mix and mingle colors of two images.


User Manual
The application is capable of converting images to HSL and LAB color spaces to get different set of results with the same set of images.
First, you choose the image, which colors you want to mix with another image, by pressing the 'Choose' button below the first oblong rectangle.
Second step is to load an image to get colors from by pressing the next 'Choose' button.
You're all set up. Now, make magic happen by pressing the 'Convert' button, and... presto! You got your first image have the same color palette as the second image!
Switch the color space by pressing the 'Switch The Color Space' and you get a different result!
If you want to mix your images in two ways at once, press 'Convert Both', which will yield two results.
And finally, save the results to your computer via the 'Save' buttons below the resulting images.


Subtasks
Реализация алгоритма: +
Применение алгоритма в цветовом пространстве HSL: +
Возможность изменять каналы как одновременно, так и по отдельности: +
Возможность изменять/не изменять контраст при перекраске: +





