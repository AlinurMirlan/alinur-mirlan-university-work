Introduction
Greetings, User. This application is designed to create a route that leads to a treasure based on the arrows in the image file that point to it.


User Manual
* Open an image file containing arrows and the treasure they point to by pressing the 'Open Image' button.
* Process the selected image file to draw the treasure route by pressing the 'Find Treasure' button.
* Have some salt-and-pepper noise on your image? No problem! Eradicate the noise by specifying the radius of the Median filter's kernel in the text box and pressing the 'Median Filter' button.
* Normalize the color palette of the selected image by pressing the 'Grey World Filter' button


Subtasks
Реализация медианной фильтрации с задаваемым размером окрестности: +
Оконтуривание клада методами выделения краев или мат. морфологии: +
Реализация операций математической морфологии (открытие): +
Реализация одного из методов коррекции контрастности/цветности; (серый мир): +






