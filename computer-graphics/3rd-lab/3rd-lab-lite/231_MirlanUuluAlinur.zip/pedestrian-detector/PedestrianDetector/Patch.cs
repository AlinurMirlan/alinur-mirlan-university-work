﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedestrianDetector;

public static class Patch
{
    public static readonly int Width = 80;
    public static readonly int TopY = 0;
    public static readonly int BottomY = 200;
    public static readonly int Height = 200;
}
