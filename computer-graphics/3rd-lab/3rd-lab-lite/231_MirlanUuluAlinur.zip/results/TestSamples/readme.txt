Since the lab with pictures weighs too much, I removed the pictures from the archive.
Put the test samples along with the pedestrians' locations in here